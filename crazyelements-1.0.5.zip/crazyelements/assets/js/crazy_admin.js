(function ($) {
    "use strict";
    $(document).ready(function() {
        $('#hook').select2();
    });
  })(jQuery);