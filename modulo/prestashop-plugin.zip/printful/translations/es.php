<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{printful}prestashop>printful_2088f6ff44376f2b68168919d8e0cfbd'] = 'Printful: impresión bajo demanda y gestión logística';
$_MODULE['<{printful}prestashop>printful_ab2eb5a79b65b710308c34b11cba037e'] = '¡Usa Printful para diseñar y vender tus propias camisetas, gorras, mochilas y mucho más! Nosotros nos encargamos del inventario, la producción y el envío, para que tú puedas centrarte en construir tu negocio.';
$_MODULE['<{printful}prestashop>connect_4d2e34921efec34c4c98177dcaf5bb94'] = '¡Ya casi has acabado! Crea una nueva clave API o selecciona una existente que hayas creado para tu integración con Printful y clica en “Conectar”. ¡Tu tienda PrestaShop se conectará con Printful para así poder procesar tus pedidos de forma automática!';
